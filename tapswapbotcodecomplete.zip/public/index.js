import plutos from '../images/plutotap.svg'
import bronze from '../images/bronze.webp'
import Silver from '../images/sliver.webp'
import gold from '../images/gold.webp'
import diamond from '../images/diamond.webp'
import platinum from '../images/platinum.webp'
import master from '../images/master.webp'
import tapcoin from '../images/tapme1.webp'
import lihgt from '../images/lihgt.webp'
// import plutos from '../images/'
// import plutos from '../images/'
// import plutos from '../images/'
// import plutos from '../images/'
// import plutos from '../images/'

export {
    plutos,
    bronze,
    Silver,
    gold,
    diamond,
    platinum,
    master,
    tapcoin,
    lihgt
}